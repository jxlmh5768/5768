/*var empJob = $.context.empData.d.results[0].empInfo.jobInfoNav.results[0];
 var empData = $.context.empData.d.results[0];
*/
 /************ Prepare Input Payload to Execute Rules ****************/
 /*var employee = {};
 employee.countryOfCompany = "USA";
 employee.isFullTimeEmployee = empJob.isFulltimeEmployee;
 employee.company = empJob.company;
 employee.jobTitle = empJob.jobTitle;
*/
// var empData = $.context.empData.d.results[0];
//  var Vocabulary = [{
// 	"Equipment":{
// 		"TotalAmount": $.context.TotalAmount
// 		}
//  }];
//  var rulesPayload = {
//   "RuleServiceId": "ecfb4b31b9254b42ba04d93952be269d",
//   "RuleServiceVersion": "000001000000000002",
//   "Vocabulary": Vocabulary
//  };
 $.context.apprvoalnum = 0 ;
//  var apprvoalnum =  0;
 $.context.apprvoalflag = false ;
//  $.context.rulesPayload = rulesPayload;
 $.context.usernum = $.context.userarr.length
 var arr = $.context.userarr;

//  $.context.AllUsers = $.context.userarr[0].mail;
//  $.context.AllUserNames =  $.context.userarr[0].username;
 $.context.usermail = $.context.userarr[0].mail;
 $.context.username = $.context.userarr[0].username;


// for(var i= 1; i< $.context.userarr[0].length ; i++){
//     $.context.AllUsers = $.context.AllUsers+","+$.context.userarr[i].mail
//     $.context.AllUserNames =  $.context.AllUserNames+","+$.context.userarr[i].username
// }
// var approvetype = 0;
// approvetype = $.context.ApprovalType;
// if(approvetype===2){

// }else{
//     $.context.usermail = $.context.AllUsers;
//     $.context.username = $.context.AllUserNames;
// }



// $.context.usermail = arr[$.context.apprvoalnum]
// $.context.usermail1 = arr[0]
// $.context.usermail2 = arr[apprvoalnum]
 /************ Enhance Workflow Context for additional attributes ****************/
 /*var attributes = {
  username: empData.firstName + " " + empData.lastName,
  division: empData.division,
  city: empData.city,
  country: empData.country,
  jobCode: empData.jobCode,
  jobTitle: empJob.jobTitle
 };
 $.context.empData.personalInfo = attributes;*/
