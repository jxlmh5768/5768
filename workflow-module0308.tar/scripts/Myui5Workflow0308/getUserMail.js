// if($.context.stauts.Result[0].EquipmentApproval.ApprovalNeeded === false){
//     $.context.usermail = "zhihao_wu@ccpgp.com";
// }else{
//     $.context.usermail = "jun_miao@ccpgp.com";
// }
// $.context.usermail = "jun_miao@ccpgp.com" + ',' + "btp_dev@jy-info.net";
// $.context.usermailArray = ["jun_miao@ccpgp.com" , "btp_dev@jy-info.net"];
// $.context.usermail = $.context.usermailArray[1];
// for( var i = 1 ; i < $.context.usermailArray.length ; i++){
//     $.context.usermail = $.context.usermail+","+$.context.usermailArray[i];
// }
