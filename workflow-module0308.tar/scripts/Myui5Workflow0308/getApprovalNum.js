// if($.usertasks.usertask5.last.decision=="approve"){
// 	$.context.apprvoalnum = $.context.apprvoalnum + 1;
// }
// $.context.usertask = $.usertasks.usertask5.last ;

var usernum =  0 
var apprvoalnum = 0 ;
var approvetype = 0;

usernum = $.context.usernum;
apprvoalnum =  $.context.apprvoalnum ;
approvetype = $.context.ApprovalType;
$.context.last = $.usertasks.usertask5.last;
if(approvetype===2){
    $.context.parallelflag = false ;
    var sMail = $.context.usermail;
    var sprocessor = $.usertasks.usertask5.last.processor;
    var sReplace = sprocessor+",";
    if(sMail.length > 0 ){
        sMail = sMail.replace(sReplace,"");
        var sReplace = ","+sprocessor;
        sMail = sMail.replace(sReplace,"");
        sMail = sMail.replace(sprocessor,"");
        $.context.usermail = sMail;
    }else{
        $.context.apprvoalflag = true ;
    }
}else{
    $.context.parallelflag = true;
    if(apprvoalnum < usernum - 1){
        apprvoalnum += 1;
        $.context.usermail = $.context.userarr[apprvoalnum].mail
        
        $.context.apprvoalnum = apprvoalnum;
        // $.context.AllUsers = $.context.AllUsers+","+$.context.usermail
    }else{
        $.context.apprvoalflag = true ;
    }

}

